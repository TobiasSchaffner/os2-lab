/* Where a program's output goes, and how it ends.
 *
 * Built for the host (cc): ordinary stdio.
 * Built for RISC-V (-DBARE): no operating system at all. One store to the
 * UART per character, and a store to QEMU's test device to power off.
 * Both the interpreter and the translated program include this file.
 */
#ifndef PLATFORM_H
#define PLATFORM_H

#ifdef BARE
#define UART      0x10000000UL  /* 16550 transmit register */
#define POWEROFF  0x00100000UL  /* virt board's test device */

static void putc_(char c)
{
	*(volatile unsigned char *)UART = c;
}

static void __attribute__((noreturn, unused)) halt(void)
{
	*(volatile unsigned int *)POWEROFF = 0x5555;
	for (;;)
		;
}
#else
#include <stdio.h>
#include <stdlib.h>

static void putc_(char c)
{
	putchar(c);
}

static void __attribute__((noreturn, unused)) halt(void)
{
	exit(0);
}
#endif

static void __attribute__((unused)) puts_(const char *s)
{
	while (*s)
		putc_(*s++);
}

static void __attribute__((unused)) putdec(unsigned long n)
{
	char buf[24];
	int i = sizeof buf;

	buf[--i] = 0;
	do
		buf[--i] = '0' + n % 10;
	while (n /= 10);
	puts_(&buf[i]);
}

static void __attribute__((unused)) puthex(unsigned long n)
{
	int i;

	puts_("0x");
	for (i = 60; i >= 0; i -= 4)
		putc_("0123456789abcdef"[(n >> i) & 15]);
}

/* Print a number and a newline. */
static void __attribute__((unused)) print_value(long n)
{
	char buf[24];
	int i = sizeof buf;
	int neg = n < 0;
	unsigned long u = neg ? -(unsigned long)n : (unsigned long)n;

	buf[--i] = 0;
	buf[--i] = '\n';
	do
		buf[--i] = '0' + u % 10;
	while (u /= 10);
	if (neg)
		buf[--i] = '-';
	puts_(&buf[i]);
}

#endif
