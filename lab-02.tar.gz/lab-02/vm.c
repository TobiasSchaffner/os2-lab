/* The virtual machine: an interpreter for our bytecode.
 *
 * The program is compiled in (build/program.h), so the same file runs on
 * the host and, without any operating system, on a RISC-V machine.
 *
 * The machine's whole state: the bytecode, a program counter into it,
 * and a stack.
 */
#include "bytecode.h"
#include "platform.h"
#include "program.h"

static long stack[256];

int main(void)
{
	unsigned long pc;       /* index of the next opcode in program[] */
	int sp;                 /* number of values on the stack */
	int run;

	/* The whole program, RUNS times (make RUNS=...). Every run decodes
	 * every opcode again. */
	for (run = 0; run < RUNS; run++)
		/* The dispatch loop: fetch an opcode, jump to its case, execute it. */
		for (pc = 0, sp = 0; pc < sizeof program; ) {
			unsigned char op = program[pc++];

			switch (op) {
			case OP_CONST:
				stack[sp++] = program[pc++];
				break;
			case OP_ADD:
				sp--;
				stack[sp - 1] = stack[sp - 1] + stack[sp];
				break;
			case OP_SUB:
				sp--;
				stack[sp - 1] = stack[sp - 1] - stack[sp];
				break;
			case OP_MUL:
				sp--;
				stack[sp - 1] = stack[sp - 1] * stack[sp];
				break;
			case OP_PRINT:
				print_value(stack[--sp]);
				break;
			default:
				halt();     /* not an opcode: stop the machine */
			}
		}
	halt();
}
