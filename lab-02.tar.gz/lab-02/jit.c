/* The just-in-time compiler: bytecode in, RISC-V machine code out, at
 * run time, into an array. Then jump into the array.
 *
 * The generated code is a C function:
 *
 *   void jitted(long *stack, void (*print)(long));
 *
 * While it runs, s2 points to the next free slot of the stack and s1
 * holds the address of print_value.
 */
#include <stdint.h>
#include "bytecode.h"
#include "platform.h"
#include "program.h"

/* Register numbers, as in the RISC-V calling convention. */
enum { zero = 0, ra = 1, sp = 2, t0 = 5, t1 = 6, s1 = 9, a0 = 10, a1 = 11, s2 = 18 };

/* ------------------------------------------------------------------ */
/* The encoders. Each writes one 32-bit instruction into the buffer.   */

static uint32_t code[4096] __attribute__((aligned(4)));
static int n;

static void emit(uint32_t insn)
{
	if (n == sizeof code / sizeof code[0]) {
		puts_("jit: code buffer full\n");
		halt();
	}
	code[n++] = insn;
}

/* The instruction formats (Volume I, chapter "RV32I Base Integer ISA") */
#define R(f7, rs2, rs1, f3, rd, op) \
	emit((uint32_t)(f7) << 25 | (rs2) << 20 | (rs1) << 15 | (f3) << 12 | (rd) << 7 | (op))
#define I(imm, rs1, f3, rd, op) \
	emit(((uint32_t)(imm) & 0xfff) << 20 | (rs1) << 15 | (f3) << 12 | (rd) << 7 | (op))
#define S(imm, rs2, rs1, f3, op) \
	emit(((uint32_t)(imm) >> 5 & 0x7f) << 25 | (rs2) << 20 | (rs1) << 15 | (f3) << 12 | \
	     ((uint32_t)(imm) & 0x1f) << 7 | (op))

/* The instructions we need */
#define ADDI(rd, rs, imm)  I(imm, rs, 0, rd, 0x13)   /* rd = rs + imm (-2048..2047) */
#define LD(rd, rs, off)    I(off, rs, 3, rd, 0x03)   /* rd = 64 bits at rs + off */
#define SD(rs2, rs, off)   S(off, rs2, rs, 3, 0x23)  /* 64 bits at rs + off = rs2 */
#define ADD(rd, a, b)      R(0x00, b, a, 0, rd, 0x33) /* rd = a + b */
#define SUB(rd, a, b)      R(0x20, b, a, 0, rd, 0x33) /* rd = a - b */
#define MUL(rd, a, b)      R(0x01, b, a, 0, rd, 0x33) /* rd = a * b (M extension) */
#define JALR(rd, rs, off)  I(off, rs, 0, rd, 0x67)   /* rd = pc + 4, jump to rs + off */

/* ------------------------------------------------------------------ */
/* The translator.                                                     */

static void translate(void)
{
	unsigned long pc = 0;

	/* Prolog: save what we use, then s2 = stack, s1 = print. */
	ADDI(sp, sp, -32);
	SD(ra, sp, 24);
	SD(s1, sp, 16);
	SD(s2, sp, 8);
	ADDI(s2, a0, 0);
	ADDI(s1, a1, 0);

	/* One pass over the bytecode: a few instructions per opcode. */
	while (pc < sizeof program) {
		unsigned char op = program[pc++];

		switch (op) {
		case OP_CONST:
			ADDI(t0, zero, program[pc++]);  /* t0 = n */
			SD(t0, s2, 0);                  /* push t0 */
			ADDI(s2, s2, 8);
			break;
		case OP_ADD:
			/* TODO: pop two values, push their sum */
			break;
		case OP_SUB:
			/* TODO: pop two values, push their difference */
			break;
		case OP_MUL:
			/* TODO: pop two values, push their product */
			break;
		case OP_PRINT:
			ADDI(s2, s2, -8);               /* pop */
			LD(a0, s2, 0);                  /* a0 = the value */
			JALR(ra, s1, 0);                /* call print_value */
			break;
		default:
			puts_("jit: unknown opcode\n");
			halt();
		}
	}

	/* Epilog: restore and return to the caller. */
	LD(ra, sp, 24);
	LD(s1, sp, 16);
	LD(s2, sp, 8);
	ADDI(sp, sp, 32);
	JALR(zero, ra, 0);
}

/* ------------------------------------------------------------------ */

/* If an encoding is wrong, the CPU traps. Say where instead of hanging. */
static void __attribute__((interrupt("machine"), aligned(4))) m_trap(void)
{
	unsigned long cause, epc;

	asm volatile("csrr %0, mcause" : "=r"(cause));
	asm volatile("csrr %0, mepc" : "=r"(epc));
	puts_("jit: trap, mcause ");
	putdec(cause);
	puts_(" at ");
	puthex(epc);
	puts_("\n");
	halt();
}

static long stack[256];

int main(void)
{
	int run;

	asm volatile("csrw mtvec, %0" :: "r"(m_trap));

	translate();

	puts_("jit: ");
	putdec(n);
	puts_(" instructions at ");
	puthex((uintptr_t)code);
	puts_("\n");

	/* The array was written as data. Make sure the CPU fetches the new
	 * instructions, not stale ones, before jumping into it. */
	asm volatile("fence.i" ::: "memory");

	/* Translated once, run RUNS times (make RUNS=...) */
	for (run = 0; run < RUNS; run++)
		((void (*)(long *, void (*)(long)))(uintptr_t)code)(stack, print_value);

	halt();
}
