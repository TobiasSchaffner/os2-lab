/* The bytecode of our stack machine. One byte per opcode; CONST is followed
 * by one more byte, the constant.
 *
 *   CONST n   push n
 *   ADD       pop b, pop a, push a + b
 *   SUB       pop b, pop a, push a - b
 *   MUL       pop b, pop a, push a * b
 *   PRINT     pop a value and print it
 */
#ifndef BYTECODE_H
#define BYTECODE_H

enum {
	OP_CONST = 0x01,
	OP_ADD   = 0x11,
	OP_SUB   = 0x12,
	OP_MUL   = 0x13,
	OP_PRINT = 0x20,
};

#endif
