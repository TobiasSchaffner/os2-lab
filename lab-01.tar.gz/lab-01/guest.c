/* The guest: a very small kernel that believes it owns the machine.
 *
 * It is written like any RISC-V kernel in S-mode: it checks that its
 * interrupt flag works, installs a trap handler, arms its timer, and then
 * sleeps. Once per second the timer interrupt wakes it, it says Hi!, and
 * arms the timer again.
 *
 * build/guest.elf  runs it directly on QEMU's CPU, in S-mode. Everything works.
 * build/vmm.elf    runs it on the hypervisor, in U-mode. Every privileged
 *                  instruction traps, and the hypervisor must make the guest
 *                  believe it worked.
 *
 * This file is linked into its own 2 MiB, at the same address in both
 * images, and in the hypervisor's image the only memory U-mode may touch.
 */
#include "riscv.h"

static void putc_(char c)
{
	/* The serial port, memory-mapped. One store per character. */
	asm volatile("sb %0, 0(%1)" :: "r"(c), "r"(UART) : "memory");
}
#include "print.h"

char guest_stack[16384] __attribute__((aligned(16)));

/* Where S-mode starts: set up a stack, then C. */
asm(".pushsection .text\n"
    ".globl guest_entry\n"
    "guest_entry:\n"
    "	la sp, guest_stack + 16384\n"
    "	j guest_main\n"
    ".popsection");

/* Does the interrupt flag behave like on a real CPU? Silent if it does. */
static void check(const char *what, int ok)
{
	if (ok)
		return;
	puts_("guest: WRONG: interrupt flag ");
	puts_(what);
	puts_("\n");
}

/* The trap handler. The compiler saves every register it uses on entry
 * and ends the function with sret. */
static void __attribute__((interrupt("supervisor"), aligned(4), used)) trap(void)
{
	unsigned long cause = csr_read(CSR_SCAUSE);

	if (cause != CAUSE_TIMER) {
		puts_("guest: unexpected trap, cause ");
		puthex(cause);
		puts_("\n");
		for (;;)
			;
	}
	puts_("Hi!\n");
	csr_write(CSR_STIMECMP, now() + TIMER_HZ);  /* again in one second */
}

void guest_main(void)
{
	unsigned long flags;

	puts_("guest: hello. I am a kernel, and this machine is mine.\n");

	csr_clear(CSR_SSTATUS, SSTATUS_SIE);
	check("cleared, reads off", !(csr_read(CSR_SSTATUS) & SSTATUS_SIE));
	csr_set(CSR_SSTATUS, SSTATUS_SIE);
	check("set, reads on", csr_read(CSR_SSTATUS) & SSTATUS_SIE);

	csr_clear(CSR_SSTATUS, SSTATUS_SIE);
	flags = csr_read(CSR_SSTATUS);
	csr_set(CSR_SSTATUS, SSTATUS_SIE);
	csr_write(CSR_SSTATUS, flags);
	check("restored, reads off", !(csr_read(CSR_SSTATUS) & SSTATUS_SIE));

	puts_("guest: waking up once per second\n");
	csr_write(CSR_STVEC, trap);
	csr_set(CSR_SIE, SIE_STIE);
	csr_write(CSR_STIMECMP, now() + TIMER_HZ);
	csr_set(CSR_SSTATUS, SSTATUS_SIE);

	for (;;)
		asm volatile("wfi");  /* sleep until the next interrupt */
}
