/* Minimal output, included by both the hypervisor and the guest.
 *
 * Each gets its own copy, compiled into its own memory: the guest may not
 * execute the hypervisor's code, and must not even be able to read it.
 * The includer defines putc_() first.
 */
static void __attribute__((unused)) puts_(const char *s)
{
	while (*s)
		putc_(*s++);
}

static void __attribute__((unused)) putdec(unsigned long n)
{
	char buf[24];
	int i = sizeof buf;

	buf[--i] = 0;
	do
		buf[--i] = '0' + n % 10;
	while (n /= 10);
	puts_(&buf[i]);
}

static void __attribute__((unused)) puthex(unsigned long n)
{
	int i;

	puts_("0x");
	for (i = 60; i >= 0; i -= 4)
		putc_("0123456789abcdef"[(n >> i) & 15]);
}
