/* RISC-V supervisor registers and how to reach them, for the guest and
 * the hypervisor alike. */
#ifndef RISCV_H
#define RISCV_H

/* CSR numbers */
#define CSR_SSTATUS     0x100
#define CSR_SIE         0x104
#define CSR_STVEC       0x105
#define CSR_SCOUNTEREN  0x106
#define CSR_SSCRATCH    0x140
#define CSR_SEPC        0x141
#define CSR_SCAUSE      0x142
#define CSR_STVAL       0x143
#define CSR_SIP         0x144
#define CSR_STIMECMP    0x14d   /* Sstc: the supervisor's own timer */
#define CSR_SATP        0x180

/* sstatus */
#define SSTATUS_SIE     (1UL << 1)   /* interrupts enabled */
#define SSTATUS_SPIE    (1UL << 5)   /* SIE before the last trap */
#define SSTATUS_SPP     (1UL << 8)   /* mode before the last trap: 1 = S */
#define SSTATUS_SUM     (1UL << 18)  /* S-mode may touch user pages */

/* sie, sip */
#define SIE_STIE        (1UL << 5)   /* timer interrupt enabled */

/* scause: the top bit says "interrupt" */
#define CAUSE_INTERRUPT         (1UL << 63)
#define CAUSE_TIMER             (CAUSE_INTERRUPT | 5)
#define CAUSE_ILLEGAL_INSN      2
#define CAUSE_STORE_PAGE_FAULT  15

#define UART      0x10000000UL  /* 16550 transmit register */
#define TIMER_HZ  10000000UL    /* the virt machine's clock: 10 MHz */

#define csr_read(csr) ({ unsigned long v_; \
	asm volatile("csrr %0, %1" : "=r"(v_) : "i"(csr) : "memory"); v_; })
#define csr_write(csr, v) \
	asm volatile("csrw %0, %1" :: "i"(csr), "r"((unsigned long)(v)) : "memory")
#define csr_set(csr, v) \
	asm volatile("csrs %0, %1" :: "i"(csr), "r"((unsigned long)(v)) : "memory")
#define csr_clear(csr, v) \
	asm volatile("csrc %0, %1" :: "i"(csr), "r"((unsigned long)(v)) : "memory")

/* Not privileged: S-mode and, if allowed, U-mode may read the clock. */
static inline unsigned long now(void)
{
	unsigned long t;

	asm volatile("rdtime %0" : "=r"(t));
	return t;
}

#endif
