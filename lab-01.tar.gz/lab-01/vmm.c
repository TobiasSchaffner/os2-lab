/* The hypervisor. It runs in S-mode, where a kernel would run, and runs the
 * guest kernel in U-mode.
 *
 * Every privileged instruction of the guest traps into vmm_trap(). The
 * hypervisor finds out what the guest tried, does it on the *virtual* CPU
 * (struct vcpu), and lets the guest continue as if the real CPU had done it.
 */
#include "riscv.h"

static void putc_(char c)
{
	*(volatile unsigned char *)UART = c;
}
#include "print.h"

#define TEST_DEVICE  0x00100000UL  /* write 0x5555 to power off */

/* The guest's registers, saved by trap.S: x0..x31, then sepc, scause,
 * stval. Change x[] or pc, and the guest continues with the new values. */
struct regs {
	unsigned long x[32];  /* x[2] is the guest's sp, x[0] is always 0 */
	unsigned long pc, cause, tval;
};

/* Fields of a 32-bit RISC-V instruction */
#define OPCODE(i)  ((i) & 0x7f)
#define RD(i)      (((i) >> 7) & 31)
#define FUNCT3(i)  (((i) >> 12) & 7)
#define RS1(i)     (((i) >> 15) & 31)
#define RS2(i)     (((i) >> 20) & 31)
#define CSR(i)     ((i) >> 20)
#define OP_SYSTEM  0x73  /* csr*, wfi, sret, ecall */
#define OP_STORE   0x23  /* sb, sh, sw, sd */
#define INSN_SRET  0x10200073

extern char guest_start[], boot_stack_top[], trap_entry[];
void guest_entry(void);

static int in_guest(unsigned long addr)
{
	return addr - (unsigned long)guest_start < 0x200000;
}

static void __attribute__((noreturn)) poweroff(void)
{
	*(volatile unsigned int *)TEST_DEVICE = 0x5555;
	for (;;)
		;
}

static const char *cause_name(unsigned long cause)
{
	switch (cause) {
	case CAUSE_ILLEGAL_INSN:     return "illegal instruction";
	case CAUSE_STORE_PAGE_FAULT: return "store page fault";
	case 8:                      return "ecall from U-mode";
	case 12:                     return "instruction page fault";
	case 13:                     return "load page fault";
	default:                     return "see the privileged spec";
	}
}

/* Why an instruction was illegal for the guest: the lowest mode that may
 * run it. For a CSR the number says so: bits 9:8 are that mode, and bits
 * 11:10 == 3 mean read-only. */
static void describe(unsigned int insn)
{
	static const char *const mode[] = { "U", "S", "hypervisor", "M" };
	static const char *const csrop[] = { "?", "csrrw", "csrrs", "csrrc" };
	unsigned int csr = CSR(insn);

	if (OPCODE(insn) != OP_SYSTEM) {
		puts_("not a privileged instruction: illegal in every mode");
		return;
	}
	switch (insn) {
	case 0x10200073: puts_("sret, needs S-mode"); return;
	case 0x10500073: puts_("wfi, needs S-mode"); return;
	case 0x30200073: puts_("mret, needs M-mode"); return;
	}
	if ((insn & 0xfe007fff) == 0x12000073) {
		puts_("sfence.vma, needs S-mode");
		return;
	}
	if (FUNCT3(insn) & 3) {
		puts_(csrop[FUNCT3(insn) & 3]);
		puts_(FUNCT3(insn) & 4 ? "i on CSR " : " on CSR ");
		puthex(csr);
		puts_(", needs ");
		puts_(mode[(csr >> 8) & 3]);
		puts_("-mode");
		if ((csr >> 10) == 3)
			puts_(", read-only");
		return;
	}
	puts_("unknown SYSTEM instruction");
}

static void __attribute__((noreturn)) panic(struct regs *r, const char *why)
{
	puts_("\nvmm: ");
	puts_(why);
	puts_("\n  scause ");
	puthex(r->cause);
	puts_(" (");
	puts_(cause_name(r->cause));
	puts_(")\n  sepc   ");
	puthex(r->pc);
	puts_("\n  stval  ");
	puthex(r->tval);
	if (in_guest(r->pc)) {
		puts_("\n  instruction at sepc: ");
		puthex(*(unsigned int *)r->pc);
		if (r->cause == CAUSE_ILLEGAL_INSN) {
			puts_("\n  that is: ");
			describe(*(unsigned int *)r->pc);
			puts_("; the guest runs in U-mode");
		}
	}
	puts_("\nvmm: stopping the machine\n");
	poweroff();
}

/* The virtual CPU: the supervisor registers as the guest believes them. */
static struct {
	unsigned long sstatus, sie, stvec, sscratch, sepc, scause, stval;
	unsigned long stimecmp;
} vcpu = { .stimecmp = -1UL };

static unsigned long *virtual_csr(unsigned int csr)
{
	switch (csr) {
	case CSR_SSTATUS:  return &vcpu.sstatus;
	case CSR_SIE:      return &vcpu.sie;
	case CSR_STVEC:    return &vcpu.stvec;
	case CSR_SSCRATCH: return &vcpu.sscratch;
	case CSR_SEPC:     return &vcpu.sepc;
	case CSR_SCAUSE:   return &vcpu.scause;
	case CSR_STVAL:    return &vcpu.stval;
	case CSR_STIMECMP: return &vcpu.stimecmp;
	default:           return 0;
	}
}

/* csrrw, csrrs, csrrc and their immediate forms csrrwi, csrrsi, csrrci */
static void emulate_csr(struct regs *r, unsigned int insn)
{
	unsigned long *csr = virtual_csr(CSR(insn)), old, val;

	if (!csr)
		panic(r, "the guest uses a CSR the virtual CPU does not have");
	old = *csr;
	val = FUNCT3(insn) & 4 ? RS1(insn) : r->x[RS1(insn)];
	switch (FUNCT3(insn) & 3) {
	case 1:
		*csr = val;
		break;
	case 2:
		*csr |= val;
		break;
	case 3:
		*csr &= ~val;
		break;
	}
	if (RD(insn))
		r->x[RD(insn)] = old;
	r->pc += 4;
}

/* Return from the guest's trap handler: what the CPU does on sret. */
static void emulate_sret(struct regs *r)
{
	if (!(vcpu.sstatus & SSTATUS_SPP))
		panic(r, "the guest wants to enter its user mode; not supported");
	r->pc = vcpu.sepc;
	if (vcpu.sstatus & SSTATUS_SPIE)
		vcpu.sstatus |= SSTATUS_SIE;
	else
		vcpu.sstatus &= ~SSTATUS_SIE;
	vcpu.sstatus |= SSTATUS_SPIE;
	vcpu.sstatus &= ~SSTATUS_SPP;
}

/* If the guest's timer is due and the guest accepts interrupts, do what
 * the CPU does when an interrupt arrives (lecture 3), on the virtual CPU.
 * ponytail: only checked on a trap; a guest that never traps is never
 * interrupted. A real hypervisor arms the real timer for that. */
static void deliver_interrupt(struct regs *r)
{
	if (!(vcpu.sstatus & SSTATUS_SIE) || !(vcpu.sie & SIE_STIE) ||
	    now() < vcpu.stimecmp)
		return;
	vcpu.sepc = r->pc;
	vcpu.scause = CAUSE_TIMER;
	vcpu.stval = 0;
	vcpu.sstatus |= SSTATUS_SPIE | SSTATUS_SPP;  /* SIE was on, from S */
	vcpu.sstatus &= ~SSTATUS_SIE;
	r->pc = vcpu.stvec & ~3UL;
}

void vmm_trap(struct regs *r)
{
	unsigned int insn = *(unsigned int *)r->pc;

	switch (r->cause) {
	case CAUSE_STORE_PAGE_FAULT:
		/* The serial port, which only the hypervisor may touch. */
		if (r->tval != UART || OPCODE(insn) != OP_STORE || FUNCT3(insn) != 0)
			panic(r, "the guest stores where it may not");
		putc_(r->x[RS2(insn)]);
		r->pc += 4;
		break;
	case CAUSE_ILLEGAL_INSN:
		/* TODO: one instruction of the guest is not emulated yet. */
		if (insn == INSN_SRET)
			emulate_sret(r);
		else if (OPCODE(insn) == OP_SYSTEM && FUNCT3(insn) & 3)
			emulate_csr(r, insn);
		else
			panic(r, "unhandled trap from the guest");
		break;
	default:
		panic(r, "unhandled trap from the guest");
	}
	deliver_interrupt(r);
}

/* Sv39 page tables, everything mapped 1:1. Only the 2 MiB that hold the
 * guest are user pages: the guest cannot see the hypervisor or the
 * devices, and every attempt to touch them traps. */
#define PTE_V (1UL << 0)
#define PTE_R (1UL << 1)
#define PTE_W (1UL << 2)
#define PTE_X (1UL << 3)
#define PTE_U (1UL << 4)
#define PTE_A (1UL << 6)
#define PTE_D (1UL << 7)
#define LEAF  (PTE_V | PTE_R | PTE_W | PTE_X | PTE_A | PTE_D)

static unsigned long root[512] __attribute__((aligned(4096)));
static unsigned long ram[512] __attribute__((aligned(4096)));

void vmm_main(void)
{
	unsigned long base = 0x80000000UL, g = (unsigned long)guest_start;
	int i;

	root[0] = LEAF;                      /* 0-1 GiB: devices, S only */
	root[2] = ((unsigned long)ram >> 12) << 10 | PTE_V;
	for (i = 0; i < 512; i++)            /* 2-3 GiB: RAM in 2 MiB pages */
		ram[i] = ((base + i * 0x200000UL) >> 12) << 10 | LEAF;
	ram[(g - base) >> 21] |= PTE_U;

	csr_write(CSR_STVEC, trap_entry);
	csr_write(CSR_SATP, 8UL << 60 | (unsigned long)root >> 12);
	asm volatile("sfence.vma" ::: "memory");
	csr_set(CSR_SSTATUS, SSTATUS_SUM);   /* we may read the guest's memory */
	csr_write(CSR_SCOUNTEREN, 2);        /* the guest may read the clock */

	puts_("vmm: starting the guest in user mode\n");
	csr_write(CSR_SSCRATCH, boot_stack_top);
	csr_write(CSR_SEPC, guest_entry);
	csr_clear(CSR_SSTATUS, SSTATUS_SPP); /* "return" to user mode */
	asm volatile("sret");
	__builtin_unreachable();
}
