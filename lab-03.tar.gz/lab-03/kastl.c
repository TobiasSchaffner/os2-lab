/*
 * kastl: a sandbox you build yourself.
 *
 *   kastl COMMAND [ARGS...]
 *
 * Right now it is almost empty: it starts the command as a child and waits
 * for it. No isolation at all. To run the hacker inside it:
 *
 *   make
 *   ./build/kastl ./build/hacker
 */
#define _GNU_SOURCE
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

/* The child: for now it just becomes the command. Everything that makes this
 * a kastl, you add here (and in the clone() flags below). */
static int child(void *arg)
{
	char **command = arg;

	execvp(command[0], command);
	perror(command[0]);
	return 127;
}

int main(int argc, char **argv)
{
	static char stack[1 << 20];
	int status;

	if (argc < 2) {
		fprintf(stderr, "usage: %s COMMAND [ARGS...]\n", argv[0]);
		return 2;
	}

	/* Start the command as a child. */
	int flags = SIGCHLD;
	pid_t pid = clone(child, stack + sizeof stack, flags, argv + 1);
	if (pid < 0) {
		perror("clone");
		return 1;
	}

	if (waitpid(pid, &status, 0) < 0) {
		perror("waitpid");
		return 1;
	}
	return WIFEXITED(status) ? WEXITSTATUS(status) : 128 + WTERMSIG(status);
}
