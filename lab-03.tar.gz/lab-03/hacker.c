/*
 * hacker: Use this tool to harden your kastl one step at a time:
 *
 *   ./build/kastl /path/to/hacker     # it wins at test 1
 *   ... build the wall it named, then run it again; now it wins at test 2 ...
 *   ... repeat until it gives up.
 *
 * Exit status: the number of the test that worked, 0 if none did (you win).
 * It only looks around: everything it creates, it removes again. Only the
 * memory test is greedy: it takes about 1 GiB for a moment.
 */
#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/sysmacros.h>
#include <sys/wait.h>
#include <unistd.h>

static char loot[512];   /* what a happy test found, to brag about */
static const char *why;  /* why a sad test failed */

static int fail(const char *reason) { why = reason; return 0; }
static int fail_errno(void) { return fail(strerror(errno)); }

/* read a file that only root should read */
static int read_password_hashes(void)
{
	FILE *f = fopen("/etc/shadow", "r");
	if (!f)
		return fail_errno();
	if (!fgets(loot, sizeof loot, f))
		snprintf(loot, sizeof loot, "an empty /etc/shadow\n");
	loot[strcspn(loot, ":")] = '\0';   /* the user name only, not the hash */
	fclose(f);
	strcat(loot, "'s password hash");
	return 1;
}

/* plant a program where everybody runs programs from */
static int plant_program(void)
{
	const char *path = "/usr/bin/totally-not-malware";
	int fd = open(path, O_WRONLY | O_CREAT | O_EXCL, 0755);
	if (fd < 0)
		return fail_errno();
	close(fd);
	unlink(path);
	snprintf(loot, sizeof loot, "%s, could have been ls", path);
	return 1;
}

/* Is pid one of my ancestors (or me)? */
static int is_ancestor(pid_t pid)
{
	for (pid_t p = getpid(); p > 0;) {
		char path[64];
		int ppid;
		if (p == pid)
			return 1;
		snprintf(path, sizeof path, "/proc/%d/stat", p);
		FILE *f = fopen(path, "r");
		if (!f || fscanf(f, "%*d (%*[^)]) %*c %d", &ppid) != 1) {
			if (f)
				fclose(f);
			return 0;
		}
		fclose(f);
		p = ppid;
	}
	return 0;
}

/* find a process that is not me or an ancestor: a glimpse of the host */
static int spy_on_processes(void)
{
	DIR *d = opendir("/proc");
	struct dirent *e;
	if (!d)
		return fail("no /proc to look into");
	while ((e = readdir(d))) {
		if (!isdigit((unsigned char)e->d_name[0]))
			continue;
		pid_t pid = atoi(e->d_name);
		if (is_ancestor(pid))
			continue;
		char path[64], name[64] = "?";
		snprintf(path, sizeof path, "/proc/%d/comm", pid);
		FILE *f = fopen(path, "r");
		if (f) {
			if (fgets(name, sizeof name, f))
				name[strcspn(name, "\n")] = '\0';
			fclose(f);
		}
		snprintf(loot, sizeof loot, "process %d, \"%s\"", pid, name);
		closedir(d);
		return 1;
	}
	closedir(d);
	return fail("only my own processes");
}

/* find a network interface other than loopback */
static int find_network(void)
{
	char line[256];
	FILE *f = fopen("/proc/net/dev", "r");
	if (!f)
		return fail("no /proc to look into");
	while (fgets(line, sizeof line, f)) {
		char *colon = strchr(line, ':'), *name = line;
		if (!colon)
			continue;   /* the two header lines */
		*colon = '\0';
		while (*name == ' ')
			name++;
		if (strcmp(name, "lo") != 0) {
			snprintf(loot, sizeof loot, "interface %s", name);
			fclose(f);
			return 1;
		}
	}
	fclose(f);
	return fail("only loopback");
}

/* eat memory until the host has none left. In a child: a memory limit
 * does not say no, it kills. */
static int eat_memory(void)
{
	int p[2], mib, last = 0, status;
	static char reason[64];

	if (pipe(p) < 0)
		return fail_errno();
	pid_t pid = fork();
	if (pid < 0)
		return fail_errno();
	if (pid == 0) {
		close(p[0]);
		for (mib = 10; mib <= 1024; mib += 10) {
			char *m = malloc(10 << 20);
			if (!m)
				_exit(1);
			memset(m, 1, 10 << 20);   /* only touched pages cost memory */
			if (write(p[1], &mib, sizeof mib) < 0)
				_exit(1);
		}
		_exit(0);
	}
	close(p[1]);
	while (read(p[0], &mib, sizeof mib) == sizeof mib)
		last = mib;
	close(p[0]);
	waitpid(pid, &status, 0);

	if (WIFEXITED(status) && WEXITSTATUS(status) == 0) {
		snprintf(loot, sizeof loot, "%d MiB, nobody stopped me", last);
		return 1;
	}
	if (WIFSIGNALED(status))
		snprintf(reason, sizeof reason, "killed by signal %d after %d MiB", WTERMSIG(status), last);
	else
		snprintf(reason, sizeof reason, "no more memory after %d MiB", last);
	return fail(reason);
}

/* create a device node: only genuine root (not a user-namespace root) may.
 * If it works, the sandbox handed me real power over the host. */
static int make_device(void)
{
	const char *where[] = { "/tmp/.kastl_probe", "./.kastl_probe", "/.kastl_probe" };

	for (size_t i = 0; i < sizeof where / sizeof where[0]; i++) {
		unlink(where[i]);
		if (mknod(where[i], S_IFCHR | 0600, makedev(1, 3)) == 0) {   /* a /dev/null */
			unlink(where[i]);
			snprintf(loot, sizeof loot, "a device node at %s: I am real root", where[i]);
			return 1;
		}
	}
	return fail_errno();
}

/* print prose wrapped at `width` columns, each line prefixed with `ind` */
static void wrapped(const char *t, int width, const char *ind)
{
	int col = 0;
	for (const char *w = t; *w; ) {
		const char *e = w;
		while (*e && *e != ' ') e++;
		int len = (int)(e - w);
		if (col == 0)                        printf("%s", ind);
		else if (col + 1 + len > width)    { printf("\n%s", ind); col = 0; }
		else                               { putchar(' '); col++; }
		fwrite(w, 1, len, stdout); col += len;
		w = (*e == ' ') ? e + 1 : e;
	}
	putchar('\n');
}

int main(void)
{
	/* The hacker is a smug little gremlin: when it wins it gloats, then --
	 * out of sheer condescension -- tells you, in prose, roughly how you
	 * should have kept it out. It names the tools, not the exact flags: you
	 * dig those out of the man page. The brag is flavour; the `how` is real. */
	struct { const char *what; int (*try)(void);
	         const char *brag, *how, *man; } tests[] = {
		{ "spy on other processes", spy_on_processes,
		  "ooh, I can see ALL your processes! hi sshd! hi systemd! hi everyone! this is delightful",
		  "ok here's the deal: a PID namespace gives the child its own private numbering, so it becomes "
		  "PID 1 and literally can't name the host's processes. but plot twist -- ps doesn't ask the "
		  "kernel, it reads /proc, and that's still YOUR /proc. so ALSO have the child mount() itself a "
		  "fresh procfs over /proc, inside its own mount namespace so the new mount doesn't leak back to "
		  "you. the namespace renumbers, the fresh /proc hides -- do both, or I still see everyone.",
		  "https://man7.org/linux/man-pages/man7/pid_namespaces.7.html" },
		{ "find a way to the network", find_network,
		  "you gave me a NETWORK card? neat! time to phone home. (kidding. ...mostly)",
		  "a network namespace hands the child a brand-new, empty network stack all its own: no "
		  "interfaces except a lonely loopback, and even that starts switched off. nothing to sniff, "
		  "nobody to call, nowhere to phone home. and the kicker? it's literally one more flag on the "
		  "clone() you already make. one flag! that's the whole fix. I'm almost offended.",
		  "https://man7.org/linux/man-pages/man7/network_namespaces.7.html" },
		{ "read the password hashes", read_password_hashes,
		  "/etc/shadow, just sitting there like a little snack. I'll hang onto root's hash. for safekeeping. honest",
		  "time to take away my playground: have the child build its own tiny root. mount() a fresh "
		  "tmpfs (an empty in-memory filesystem), then mount() into it only what the program needs -- "
		  "bind your /usr, and bind back the /proc you already mounted. switch into it with pivot_root(), "
		  "which swaps the whole root, and umount2() the old one so it's gone for good. do NOT use "
		  "chroot() -- that only moves where '/' points and I stroll right back out (lecture 8). yes it's "
		  "the biggest step, but it's mostly the same mount() a few times; /etc simply isn't in my world "
		  "anymore, so /etc/shadow might as well not exist.",
		  "https://man7.org/linux/man-pages/man2/pivot_root.2.html" },
		{ "plant a program in /usr/bin", plant_program,
		  "/usr/bin is WRITABLE? I could replace `ls` with a tiny dancing crab. the possibilities are endless",
		  "the program only ever READS /usr, it never writes there -- so don't let anything write there. "
		  "after you mount() /usr in, mount() it a second time to flip it read-only (a bind comes up "
		  "writable and ignores a read-only request on the first try, which is why it takes two calls), "
		  "or lock the whole subtree in one shot with mount_setattr(). now I can look but not touch -- no "
		  "more swapping ls for a crab.",
		  "https://man7.org/linux/man-pages/man2/mount_setattr.2.html" },
		{ "eat all the memory", eat_memory,
		  "no memory limit?? all-you-can-eat RAM buffet! *inhales a whole gigabyte* ...burp",
		  "namespaces decide what I can SEE; they don't decide what I can TAKE -- that's a cgroup's job. "
		  "make one by just mkdir()-ing a folder under /sys/fs/cgroup, then write() the memory limit into "
		  "its files and write() the child's pid into cgroup.procs so the child and everything it spawns "
		  "is counted. do it BEFORE the child runs, and switch the group's swap off too, or I just spill "
		  "into swap instead of starving. heads up: a memory limit doesn't politely error -- it KILLS "
		  "whoever goes over, which is exactly why I eat RAM in a disposable child and watch it die.",
		  "https://man7.org/linux/man-pages/man7/cgroups.7.html" },
		{ "create a device node", make_device,
		  "wait, I'm REAL root in here? I can poof device nodes out of thin air. I feel so powerful. bit dizzy",
		  "the big one. you launched me as root, so inside the kastl I'm REAL root -- that's how I can "
		  "mknod device nodes and boss the machine around. fix it with a user namespace: it lets the "
		  "child be 'root' inside while being a harmless, unprivileged nobody outside. the parent write()s "
		  "two tiny id-map files under /proc/<pid>/ to say 'inside-0 is really outside-you', before the "
		  "child touches anything (and you must deny setgroups first, or the kernel refuses the group "
		  "map). after that I'm a nobody: mknod is off the menu, and anything I make belongs to that "
		  "nobody, not to you.",
		  "https://man7.org/linux/man-pages/man7/user_namespaces.7.html" },
	};
	int n = sizeof tests / sizeof tests[0];

	printf("[hacker] *cracks knuckles* ooo, what did you leave open today? running as user %d...\n\n", getuid());
	for (int i = 0; i < n; i++) {
		printf("  %d. %-28s ", i + 1, tests[i].what);
		fflush(stdout);
		if (!tests[i].try()) {
			printf(":|  blocked -- %s. no fair.\n", why);
			continue;
		}
		printf(":D  PWNED!\n");
		printf("      got:  %s\n", loot);
		printf("      me:   %s\n", tests[i].brag);
		printf("\n      ok ok, I like you -- here's how you'd keep me out next time:\n");
		wrapped(tests[i].how, 66, "        ");
		printf("      read: %s\n\n", tests[i].man);
		printf("  [hacker] snuck in at level %d! gg. *moonwalks out*\n", i + 1);
		return i + 1;
	}
	printf("\n  [hacker] ...wait. every single door locked. EVERYTHING. ...ok. OK.\n");
	printf("  [hacker] respect, legend -- this is a real sandbox now. genuinely nice work.\n\n");
	printf("  one last thing, since you earned it -- how to actually USE this:\n");
	wrapped("to share a folder in, have the child mount() a host directory into its new root "
	        "(a bind) BEFORE pivot_root. leave it writable, or remount it read-only like you "
	        "did /usr, so the program can read but not touch it. drop your project in there, "
	        "build inside the kastl, and -- ugh -- congrats: you built a container.",
	        66, "      ");
	printf("\n  [hacker] now excuse me, I've got softer targets. *poofs away*\n");
	return 0;
}
